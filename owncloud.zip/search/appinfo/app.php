<?php

OC_App::register( array( 'order' => 2, "id" => 'search', 'name' => 'Search' ));

?>
