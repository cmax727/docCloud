<?php
return array(
	'ics'=>'text/calendar',
	'ical'=>'text/calendar',
	'js'=>'application/javascript',
	'odt'=>'application/vnd.oasis.opendocument.text',
	'ods'=>'application/vnd.oasis.opendocument.spreadsheet',
	'odg'=>'application/vnd.oasis.opendocument.graphics',
	'odp'=>'application/vnd.oasis.opendocument.presentation',
	'pl'=>'text/x-script.perl',
	'py'=>'text/x-script.phyton',
	'vcf' => 'text/vcard',
	'vcard' => 'text/vcard',
	'doc'=>'application/msword',
	'docx'=>'application/msword',
	'xls'=>'application/msexcel',
	'xlsx'=>'application/msexcel',
	'ppt'=>'application/mspowerpoint',
	'pptx'=>'application/mspowerpoint',
	'sgf' => 'application/sgf',
	'cdr' => 'application/coreldraw'
);
