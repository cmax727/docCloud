<?php

OC_App::register( array( "id" => "settings", "name" => "Settings" ));
OC_App::register( array( "order" => 1, "id" => "admin", "name" => "Administration" ));
OC_App::register( array( "order" => 1, "id" => "help", "name" => "Help" ));

?>
